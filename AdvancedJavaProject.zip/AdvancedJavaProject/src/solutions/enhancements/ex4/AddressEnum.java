package solutions.enhancements.ex4;

public enum AddressEnum {
    HOME, WORK
}
