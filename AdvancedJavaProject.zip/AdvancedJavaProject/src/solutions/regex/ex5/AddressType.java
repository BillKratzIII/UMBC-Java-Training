package solutions.regex.ex5;

public enum AddressType {
	WORK, HOME
}
