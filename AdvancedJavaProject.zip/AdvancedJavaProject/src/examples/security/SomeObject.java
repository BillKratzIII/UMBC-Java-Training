package examples.security;
public class SomeObject {
    private String someData;
}