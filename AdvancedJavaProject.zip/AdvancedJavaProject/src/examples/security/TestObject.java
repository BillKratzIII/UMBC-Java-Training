package examples.security;
public class TestObject {
    public static void main(String[] args) {
       SomeObject obj = new SomeObject();
       obj.someData = "Testing";
       System.out.println(obj.someData);
    }
}