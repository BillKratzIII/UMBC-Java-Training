package examples.generics;
import java.util.*;

public class WithGenerics {
    private static int length(Collection<String> c) {
        Iterator<String> i = c.iterator();
        int sum = 0;
        while(i.hasNext()){
            sum += i.next().length();
        }
        return sum;
    }
}