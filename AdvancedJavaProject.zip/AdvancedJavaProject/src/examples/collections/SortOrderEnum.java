package examples.collections;
public enum SortOrderEnum {
    LOW_TO_HIGH, HIGH_TO_LOW;
}