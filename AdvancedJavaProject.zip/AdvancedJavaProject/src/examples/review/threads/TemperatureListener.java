package examples.review.threads;

public interface TemperatureListener {
    public void temperatureChanged(int temperature);
}