package examples.review;
public class SuperClass {
    int x;
    public SuperClass(int x) {
        this.x = x;
        System.out.println("In Super Constructor");
    }
}